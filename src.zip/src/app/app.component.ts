import { Component } from '@angular/core';
import {MatSidenavModule} from '@angular/material/sidenav';
import { CommonModule } from '@angular/common'; 
import { RouterOutlet } from '@angular/router';
import { BibliothequeComponent } from './composants/bibliotheque/bibliotheque.component';
import { ChansonComponent } from "./composants/chanson/chanson.component";
import { ListeDetailleeComponent } from "./composants/liste-detaillee/liste-detaillee.component";
import { ListeChansonsComponent } from './composants/liste-chansons/liste-chansons.component';



@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
  standalone: true,
  imports: [MatSidenavModule,
    RouterOutlet,
    CommonModule,
    BibliothequeComponent,
    ChansonComponent,
    ListeDetailleeComponent,
    ListeChansonsComponent,
  
    ]
})
export class AppComponent {
  title = 'Mymusic';
}
