import { DurationPipe } from './duration-pipe.pipe';

describe('DurationPipePipe', () => {
  it('create an instance', () => {
    const pipe = new DurationPipe();
    expect(pipe).toBeTruthy();
  });
});
