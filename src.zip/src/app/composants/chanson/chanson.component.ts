import { Component, Input, OnInit, Pipe, PipeTransform } from '@angular/core';
import { Chanson } from '../../interfaces/chanson'; 
import { CommonModule } from '@angular/common';
import { DurationPipe } from '../../duration-pipe.pipe';

@Component({
  selector: 'app-chanson',
  standalone: true, 
  imports: [CommonModule, DurationPipe], 
  templateUrl: './chanson.component.html',
  styleUrls: ['./chanson.component.css'],
 
})
export class ChansonComponent implements OnInit {
  @Input() chanson!: Chanson; 

  ngOnInit(): void {
  }
}

